"""
Vision: ArUco base plate detection, hoop detection (for calibration) and drawing helpers.
"""
from itertools import combinations
from typing import Optional

import cv2
import numpy as np

import config as C

_DETECTOR = None


def _aruco():
    global _DETECTOR
    if _DETECTOR is None:
        d = cv2.aruco.getPredefinedDictionary(C.ARUCO_DICT)
        _DETECTOR = cv2.aruco.ArucoDetector(d, cv2.aruco.DetectorParameters())
    return _DETECTOR


def detect_markers(img) -> dict:
    """{id: 4x2 corner array (image px)}"""
    corners, ids, _ = _aruco().detectMarkers(img)
    out = {}
    if ids is not None:
        for c, i in zip(corners, ids.flatten()):
            out[int(i)] = c.reshape(4, 2).astype(np.float64)
    return out


def marker_center(c) -> np.ndarray:
    """Intersection of the diagonals = exact projection of the marker centre."""
    p0, p1, p2, p3 = c
    d1, d2 = p2 - p0, p3 - p1
    A = np.array([d1, -d2]).T
    try:
        s = np.linalg.solve(A, p1 - p0)[0]
        return p0 + s * d1
    except np.linalg.LinAlgError:
        return c.mean(0)


def detect_board(img, cam, z_plane) -> Optional[dict]:
    """
    Find the base plate: the pair of markers whose centres are MARKER_SPACING apart on the
    plate plane. Returns centre (flange xy at plate height), angle of the marker->marker
    vector (rad), and diagnostics. The rod stands at the plate centre (puzzle A).
    """
    markers = detect_markers(img)
    if len(markers) < 2:
        return None
    ids = sorted(markers)
    uv = {i: marker_center(markers[i]) for i in ids}
    xy = {i: cam.to_plane(uv[i], z_plane)[0] for i in ids}
    best = None
    for a, b in combinations(ids, 2):
        dist = np.linalg.norm(xy[b] - xy[a])
        err = abs(dist - C.MARKER_SPACING)
        if best is None or err < best[0]:
            best = (err, a, b, dist)
    err, a, b, dist = best
    if err > 0.25 * C.MARKER_SPACING:
        return None
    v = xy[b] - xy[a]  # a < b, so the direction is consistent between frames
    return dict(
        center=(xy[a] + xy[b]) / 2,
        angle=float(np.arctan2(v[1], v[0])),
        ids=(a, b),
        spacing=float(dist),
        spacing_err=float(dist - C.MARKER_SPACING),
        marker_uv=(uv[a], uv[b]),
        markers=markers,
    )


class BoardLocator:
    """
    Plate pose from both markers, or from ONE marker when the other is hidden (arm, hoop).
    Each marker's own orientation gives the plate orientation; the offset from a marker to
    the plate centre (in that marker's frame) is learned from frames where both are visible.
    """

    def __init__(self):
        self.rel = {}  # id -> (offset in marker frame (2,), angle delta)

    @staticmethod
    def _marker_pose(c, cam, z):
        xy = cam.to_plane(marker_center(c), z)[0]
        p = cam.to_plane(c, z)
        e = (p[1] - p[0]) + (p[2] - p[3])  # top + bottom edge direction
        return xy, float(np.arctan2(e[1], e[0]))

    def measure(self, img, cam, z):
        """(plate from both markers or None, {id: (xy, angle)} of all markers). Learns offsets."""
        b = detect_board(img, cam, z)
        markers = b["markers"] if b is not None else detect_markers(img)
        poses = {i: self._marker_pose(c, cam, z) for i, c in markers.items()}
        if b is not None:
            b["single"] = False
            for i in b["ids"]:
                xy, ang = poses[i]
                c, s = np.cos(-ang), np.sin(-ang)
                off = np.array([[c, -s], [s, c]]) @ (b["center"] - xy)
                dang = float(np.arctan2(np.sin(b["angle"] - ang), np.cos(b["angle"] - ang)))
                if i in self.rel:
                    o, d = self.rel[i]
                    off = 0.8 * o + 0.2 * off
                    dang = d + 0.2 * float(np.arctan2(np.sin(dang - d), np.cos(dang - d)))
                self.rel[i] = (off, dang)
        return b, poses, markers

    def resolve(self, poses, markers=None) -> Optional[dict]:
        """Plate from a single marker, using the learned offsets (None if not learned yet)."""
        for i, (xy, ang) in poses.items():
            if i in self.rel:
                off, dang = self.rel[i]
                c, s = np.cos(ang), np.sin(ang)
                center = xy + np.array([[c, -s], [s, c]]) @ off
                return dict(center=center, angle=ang + dang, ids=(i,), single=True,
                            markers=markers or {}, spacing_err=0.0)
        return None

    def locate(self, img, cam, z) -> Optional[dict]:
        b, poses, markers = self.measure(img, cam, z)
        return b if b is not None else self.resolve(poses, markers)


def detect_hoop(img, min_r=C.HOOP_MIN_R, max_r=C.HOOP_MAX_R, dark=C.HOOP_DARK,
                param2=C.HOUGH_PARAM2) -> Optional[dict]:
    """
    Dark hoop ring: Hough candidates (on a downscaled copy for speed), each verified by
    checking that the ring is dark all around, then a sub-pixel ellipse fit to the dark
    pixels in an annulus RELATIVE to the found radius (works at any hoop height).
    """
    gray = img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 5)
    h, w = gray.shape
    sc = min(1.0, 800.0 / w)
    small = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA) if sc < 1 else gray
    circles = cv2.HoughCircles(small, cv2.HOUGH_GRADIENT, dp=1, minDist=max(8, 0.2 * min_r * sc),
                               param1=100, param2=param2,
                               minRadius=int(min_r * sc), maxRadius=int(max_r * sc))
    if circles is None:
        return None

    th = np.linspace(0, 2 * np.pi, 180, endpoint=False)
    best = None
    for u, v, r in circles[0, :15] / sc:
        # ring score: fraction of angles where something dark lies near radius r
        hits = 0
        for f in np.linspace(0.85, 1.15, 7):
            x = np.clip((u + f * r * np.cos(th)).astype(int), 0, w - 1)
            y = np.clip((v + f * r * np.sin(th)).astype(int), 0, h - 1)
            hits = np.maximum(hits, gray[y, x] < dark)
        score = float(np.mean(hits))
        if best is None or score > best[0]:
            best = (score, u, v, r)
    score, u, v, r = best
    if score < 0.6:
        return None

    R = 1.25 * r
    x0, x1 = max(int(u - R), 0), min(int(u + R) + 1, w)
    y0, y1 = max(int(v - R), 0), min(int(v + R) + 1, h)
    yy, xx = np.mgrid[y0:y1, x0:x1]
    rr = np.hypot(xx - u, yy - v)
    m = (gray[y0:y1, x0:x1] < dark) & (rr > 0.8 * r) & (rr < 1.2 * r)
    if m.sum() < 20:
        return None
    ell = cv2.fitEllipse(np.column_stack([xx[m], yy[m]]).astype(np.float32))
    (cu, cv_), (a, b), _ = ell
    return dict(center=(float(cu), float(cv_)), radius=float((a + b) / 4), ellipse=ell, score=score)


def camera_nadir(cam) -> np.ndarray:
    """Image point straight below the camera: its ray is vertical, so both planes agree."""
    if getattr(cam, "_nadir", None) is not None:
        return cam._nadir
    uv = np.array(cam.image_size, float) / 2
    for _ in range(20):
        f = lambda p: cam.to_plane(p, cam.z_low)[0] - cam.to_plane(p, cam.z_high)[0]
        f0 = f(uv)
        J = np.column_stack([(f(uv + [1, 0]) - f0), (f(uv + [0, 1]) - f0)])
        step = np.linalg.lstsq(J, -f0, rcond=None)[0]
        uv = uv + step
        if np.linalg.norm(step) < 0.01:
            break
    cam._nadir = uv
    return uv


def detect_rod_top(img, cam, z_rod_top) -> Optional[dict]:
    """
    Orange rod seen from above: a blob that points away from the camera nadir; its far end
    is the rod top. Returns the image point and flange (x, y) of the rod axis.
    """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, np.array(C.ROD_HSV_LO), np.array(C.ROD_HSV_HI))
    lo2 = C.ROD_HSV_LO2
    m |= cv2.inRange(hsv, np.array(lo2), np.array([C.ROD_HUE_MAX, 255, 255]))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[k, cv2.CC_STAT_AREA] < C.ROD_MIN_AREA:
        return None
    ys, xs = np.nonzero(lab == k)
    pts = np.column_stack([xs, ys]).astype(float)
    nad = camera_nadir(cam)
    d = np.linalg.norm(pts - nad, axis=1)
    # rod top face ~ ROD_WIDTH across: keep the pixels within that distance of the far end
    px_per_m = np.linalg.norm(cam.to_image(cam.to_plane(nad, z_rod_top) + [C.ROD_WIDTH, 0], z_rod_top)[0]
                              - nad) / C.ROD_WIDTH
    far = pts[d >= d.max() - 0.6 * C.ROD_WIDTH * px_per_m]
    uv = far.mean(0)
    return dict(uv=uv, xy=cam.to_plane(uv, z_rod_top)[0], area=int(len(pts)))


# --------------------------------------------------------------------------------------
# Drawing
# --------------------------------------------------------------------------------------
GREEN, RED, BLUE = (90, 220, 90), (70, 70, 235), (235, 170, 60)
CYAN, ORANGE, WHITE, GRAY, YELLOW = (230, 220, 40), (40, 160, 245), (245, 245, 245), (170, 170, 170), (0, 230, 255)


def scale_of(img):
    return img.shape[1] / 1600.0


def text_box(img, lines, org, scale=None, border=None, alpha=0.7):
    """Semi-transparent dark box with lines of (text, color)."""
    s = scale_of(img) if scale is None else scale
    font, th = cv2.FONT_HERSHEY_SIMPLEX, max(1, int(round(2 * s)))
    sizes = [cv2.getTextSize(t, font, 0.8 * s, th)[0] for t, _ in lines]
    pad, gap = int(14 * s), int(12 * s)
    lh = max(sz[1] for sz in sizes) + gap
    w = max(sz[0] for sz in sizes) + 2 * pad
    h = lh * len(lines) + pad
    H, W = img.shape[:2]
    x, y = int(min(max(org[0], 0), W - w)), int(min(max(org[1], 0), H - h))
    roi = img[y:y + h, x:x + w]
    roi[:] = cv2.addWeighted(roi, 1 - alpha, np.full_like(roi, 20), alpha, 0)
    if border is not None:
        cv2.rectangle(img, (x, y), (x + w, y + h), border, th, cv2.LINE_AA)
    for i, (t, c) in enumerate(lines):
        cv2.putText(img, t, (x + pad, y + (i + 1) * lh), font, 0.8 * s, c, th, cv2.LINE_AA)


def draw_markers(vis, markers):
    s = scale_of(vis)
    for i, c in markers.items():
        pts = c.astype(np.int32)
        cv2.polylines(vis, [pts], True, CYAN, max(2, int(3 * s)), cv2.LINE_AA)
        cv2.circle(vis, tuple(int(t) for t in pts[0]), int(6 * s), RED, -1, cv2.LINE_AA)
        cv2.putText(vis, f"id {i}", (int(pts[:, 0].min()), int(pts[:, 1].min() - 12 * s)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9 * s, CYAN, max(1, int(2 * s)), cv2.LINE_AA)


def draw_cross(vis, uv, color, size=25, thick=3):
    s = scale_of(vis)
    a, t = int(size * s), max(1, int(thick * s))
    u, v = int(round(uv[0])), int(round(uv[1]))
    cv2.line(vis, (u - a, v), (u + a, v), color, t, cv2.LINE_AA)
    cv2.line(vis, (u, v - a), (u, v + a), color, t, cv2.LINE_AA)


def draw_hoop(vis, det, color=GREEN):
    if det is None:
        return
    s = scale_of(vis)
    cv2.ellipse(vis, det["ellipse"], color, max(2, int(3 * s)), cv2.LINE_AA)
    draw_cross(vis, det["center"], RED)


def show(img, name="A2", size=(1100, 700)):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(name, *size)
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyWindow(name)
