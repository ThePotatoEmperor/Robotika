"""
Simulator for testing without the robot: SCARA arm (Bosch-like API), rotating turntable
with the base plate, ArUco markers and the rod, and a pinhole camera that renders images.

It also referees the attempt: every 4 ms of simulated time it checks whether the hoop
touches the rod or the plate, and when the hoop gets below 4 cm around the rod.

The numbers here are made up (they are NOT the real station). The point is that the whole
pipeline - calibration, tracking, planning, timing - runs end to end and can be judged.
"""
import numpy as np
import cv2

import clock
import config as C

# ---------------- arm (Bosch-like SCARA, flange coordinates) ----------------
L1, L2 = 0.25, 0.20
Q_MIN = np.array([-2.6, -2.4, 0.0, -3.1])
Q_MAX = np.array([2.6, 2.4, 0.40, 3.1])
VMAX = np.array([1.0, 1.3, 0.20, 2.5])       # rad/s, m/s
T_ACC = 0.25                                  # accel/decel time of the trapezoid
CMD_LATENCY = 0.04                            # move_to_q call -> motion start
FRAME_TIME = 0.08                             # grab_image duration
HOOP_ARM = 0.135                              # hoop centre from flange along phi
HOOP_DZ = -0.020                              # hoop centre below flange

# ---------------- scene ----------------
TT_CENTER = np.array([0.34, 0.07])
TT_R = 0.10
TT_TOP = 0.040
BOARD_TOP = 0.070
MARKER_IDS = (3, 7)

# ---------------- camera (fixed, looking down, image mirrored vs. robot axes) --------
CAM = np.array([0.40, 0.02, 1.10])
F = 2600.0
W, H = 1920, 1200


def rot(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s], [s, c]])


class VirtualClock:
    def __init__(self):
        self.t = 0.0
        self.world = None

    def now(self):
        return self.t

    def sleep(self, dt):
        if dt <= 0:
            return
        if self.world is not None:
            self.world.advance(dt)
        else:
            self.t += dt


_VCLOCK = VirtualClock()


def install_clock():
    clock.set_clock(_VCLOCK)


def fk(q):
    q1, q2, q3, q4 = q
    x = L1 * np.cos(q1) + L2 * np.cos(q1 + q2)
    y = L1 * np.sin(q1) + L2 * np.sin(q1 + q2)
    return x, y, q3, q4


def ik(x, y, z=0.0, phi=0.0):
    c2 = (x * x + y * y - L1 * L1 - L2 * L2) / (2 * L1 * L2)
    if abs(c2) > 1:
        return []
    out = []
    for s2 in (np.sqrt(1 - c2 * c2), -np.sqrt(1 - c2 * c2)):
        q2 = np.arctan2(s2, c2)
        q1 = np.arctan2(y, x) - np.arctan2(L2 * s2, L1 + L2 * c2)
        q1 = (q1 + np.pi) % (2 * np.pi) - np.pi
        q = np.array([q1, q2, z, (phi + np.pi) % (2 * np.pi) - np.pi])
        if np.all(q >= Q_MIN) and np.all(q <= Q_MAX):
            out.append(q)
    return out


def bootstrap_station(st):
    """What `--testing jog` would record, from ground truth (fixed, independent of the table)."""
    phi = float(np.arctan2(TT_CENTER[1], TT_CENTER[0]))
    st.z_touch = BOARD_TOP + C.HOOP_THICK / 2 - HOOP_DZ
    flange = TT_CENTER - HOOP_ARM * np.array([np.cos(phi), np.sin(phi)])
    st.phi = phi
    st.q_ref = [float(v) for v in ik(*flange, st.z_touch + 0.2, phi)[0]]
    st.q_observe = [float(v) for v in ik(0.05, 0.30, 0.36, np.pi / 2)[0]]
    st.save()


class SimWorld:
    def __init__(self, direction="ccw", period=40.0, board_offset=(0.045, -0.02),
                 board_angle=0.4, table_center=None, seed=1):
        rng = np.random.default_rng(seed)
        self.omega = {"ccw": 2 * np.pi / period, "cw": -2 * np.pi / period, "stop": 0.0}[direction]
        self.alpha0 = rng.uniform(0, 2 * np.pi)
        self.tt = np.array(table_center) if table_center is not None else TT_CENTER.copy()
        self.board_offset = np.array(board_offset)
        self.board_angle0 = board_angle
        self.board_present = True
        self.robot = None
        self.rng = rng
        self.collision = None
        self.success = None
        self.closest = None
        _VCLOCK.world = self
        d = aruco = cv2.aruco.getPredefinedDictionary(C.ARUCO_DICT)
        self.marker_imgs = {i: cv2.aruco.generateImageMarker(d, i, 120) for i in MARKER_IDS}

    # ------------------------------------------------------------- scene state
    def board_pose(self, t):
        a = self.alpha0 + self.omega * t
        return self.tt + rot(a) @ self.board_offset, a + self.board_angle0

    def hoop(self, t):
        x, y, z, phi = fk(self.robot.q_at(t))
        return np.array([x, y]) + HOOP_ARM * np.array([np.cos(phi), np.sin(phi)]), z + HOOP_DZ, \
            np.array([x, y]), z

    # ------------------------------------------------------------- referee
    def advance(self, dt):
        end = _VCLOCK.t + dt
        while _VCLOCK.t < end - 1e-12:
            _VCLOCK.t += min(0.004, end - _VCLOCK.t)
            if self.robot is not None:
                self._check(_VCLOCK.t)

    def _check(self, t):
        if not self.board_present:
            return
        hc, hz, _, _ = self.hoop(t)
        bc, beta = self.board_pose(t)
        lo, hi = hz - C.HOOP_THICK / 2, hz + C.HOOP_THICK / 2
        rod_top = BOARD_TOP + C.ROD_FOOT + C.ROD_HEIGHT
        h = C.ROD_WIDTH / 2
        corners = bc + (rot(beta) @ np.array([[h, h], [-h, h], [-h, -h], [h, -h]]).T).T
        dmax = np.max(np.linalg.norm(corners - hc, axis=1))
        local = rot(-beta) @ (hc - bc)
        dmin = np.linalg.norm(np.maximum(np.abs(local) - h, 0))
        inside = dmax < C.HOOP_R_IN
        if lo < rod_top and hi > BOARD_TOP:
            margin = C.HOOP_R_IN - dmax
            if self.closest is None or margin < self.closest:
                self.closest = margin
            if not inside and dmin < C.HOOP_R_OUT and self.collision is None and self.success is None:
                self.collision = (t, f"hoop hit the rod (hoop at {(hi - BOARD_TOP) * 100:.1f} cm)")
        bl = rot(-beta) @ (hc - bc)
        b_dist = np.linalg.norm(np.maximum(np.abs(bl) - C.BOARD_SIZE / 2, 0))
        if lo < BOARD_TOP and b_dist < C.HOOP_R_OUT and self.collision is None and self.success is None:
            self.collision = (t, "hoop hit the plate")
        if self.success is None and self.collision is None and inside and hz - BOARD_TOP < 0.04:
            self.success = (t, hz - BOARD_TOP)

    def report(self):
        lines = ["--- simulator referee ---"]
        if self.collision:
            lines.append(f"COLLISION at t={self.collision[0]:.2f}: {self.collision[1]}")
        if self.success:
            lines.append(f"TASK FULFILLED at t={self.success[0]:.2f}: rod inside the hoop, hoop "
                         f"centre {self.success[1] * 100:.1f} cm above the plate")
        if self.closest is not None:
            lines.append(f"smallest rod-hoop clearance while overlapping in height: "
                         f"{self.closest * 1000:.1f} mm")
        if not self.collision and not self.success:
            lines.append("hoop never went down around the rod (no contact either)")
        return "\n".join(lines)

    # ------------------------------------------------------------- camera
    @staticmethod
    def project(P):
        P = np.atleast_2d(P)
        d = CAM[2] - P[:, 2]
        u = W / 2 + F * (P[:, 1] - CAM[1]) / d
        v = H / 2 + F * (P[:, 0] - CAM[0]) / d
        return np.column_stack([u, v])

    def _circle(self, c, r, z, n=90):
        th = np.linspace(0, 2 * np.pi, n, endpoint=False)
        return np.column_stack([c[0] + r * np.cos(th), c[1] + r * np.sin(th), np.full(n, z)])

    def render(self, t):
        img = np.empty((H, W, 3), np.float32)
        img[:] = (150, 185, 210)  # wood
        img *= np.linspace(0.9, 1.08, W)[None, :, None]
        poly = lambda P: self.project(P).astype(np.int32)

        cv2.fillPoly(img, [poly(self._circle(self.tt, TT_R, TT_TOP))], (235, 235, 232))
        if self.board_present:
            bc, beta = self.board_pose(t)
            R = rot(beta)
            s = C.BOARD_SIZE / 2
            sq = np.array([[s, s], [-s, s], [-s, -s], [s, -s]])
            bpts = np.column_stack([bc + (R @ sq.T).T, np.full(4, BOARD_TOP)])
            cv2.fillPoly(img, [poly(bpts)], (245, 245, 245))
            m = C.MARKER_SIZE / 2
            for mid, off in zip(MARKER_IDS, ([-C.MARKER_OFFSET, C.MARKER_OFFSET],
                                             [C.MARKER_OFFSET, -C.MARKER_OFFSET])):
                mc = bc + R @ np.array(off)
                corners = np.array([[-m, m], [m, m], [m, -m], [-m, -m]])  # TL TR BR BL
                P = np.column_stack([mc + (R @ corners.T).T, np.full(4, BOARD_TOP + 0.0004)])
                dst = self.project(P).astype(np.float32)
                mk = self.marker_imgs[mid]
                src = np.float32([[0, 0], [mk.shape[1], 0], [mk.shape[1], mk.shape[0]], [0, mk.shape[0]]])
                M = cv2.getPerspectiveTransform(src, dst)
                warped = cv2.warpPerspective(mk, M, (W, H), flags=cv2.INTER_LINEAR, borderValue=255)
                mask = cv2.warpPerspective(np.full_like(mk, 255), M, (W, H)) > 128
                img[mask] = warped[mask][:, None].astype(np.float32).repeat(3, 1)

        hc, hz, flange, fz = self.hoop(t)
        rod_top = BOARD_TOP + C.ROD_FOOT + C.ROD_HEIGHT

        def draw_rod():
            if not self.board_present:
                return
            bc, beta = self.board_pose(t)
            h = C.ROD_WIDTH / 2
            sq = (rot(beta) @ np.array([[h, h], [-h, h], [-h, -h], [h, -h]]).T).T + bc
            base = np.column_stack([sq, np.full(4, BOARD_TOP + C.ROD_FOOT)])
            top = np.column_stack([sq, np.full(4, rod_top)])
            hull = cv2.convexHull(poly(np.vstack([base, top])))
            cv2.fillPoly(img, [hull], (20, 80, 235))
            cv2.fillPoly(img, [poly(top)], (60, 130, 255))

        def draw_hoop():
            d = CAM[2] - hz
            ring = self._circle(hc, (C.HOOP_R_IN + C.HOOP_R_OUT) / 2, hz)
            th = max(2, int(F * (C.HOOP_R_OUT - C.HOOP_R_IN) / d))
            cv2.polylines(img, [poly(ring)], True, (30, 30, 30), th, cv2.LINE_AA)
            u = (flange - hc) / (np.linalg.norm(flange - hc) + 1e-9)
            a = np.r_[hc + u * C.HOOP_R_OUT, hz]
            b = np.r_[flange, fz]
            pa, pb = self.project(np.vstack([a, b])).astype(int)
            cv2.line(img, tuple(pa), tuple(pb), (90, 90, 95), max(2, int(F * 0.006 / d)), cv2.LINE_AA)

        if hz > rod_top:
            draw_rod(); draw_hoop()
        else:
            draw_hoop(); draw_rod()

        img += self.rng.normal(0, 3, img.shape).astype(np.float32)
        return cv2.GaussianBlur(np.clip(img, 0, 255).astype(np.uint8), (3, 3), 0)


class SimRobot:
    """Same calls as ctu_bosch_sr450.RobotBosch that the solution uses."""

    def __init__(self, world):
        self.world = world
        world.robot = self
        self.speed = 1.0
        self.q_home = np.array([0.0, 0.0, 0.38, 0.0])
        self.segs = []  # (t_start, q0, q1, T)

    # --- driver API
    def initialize(self, home=True):
        self.segs = [(-1.0, self.q_home, self.q_home, 0.0)]

    def soft_home(self):
        self.move_to_q(self.q_home)

    def close(self):
        pass

    def set_speed_relative(self, f):
        self.speed = f

    def in_limits(self, q):
        q = np.asarray(q)
        return bool(np.all(q >= Q_MIN - 1e-9) and np.all(q <= Q_MAX + 1e-9))

    def fk(self, q):
        return fk(q)

    def ik(self, x, y, z=0.0, phi=0.0):
        return ik(x, y, z, phi)

    def q_at(self, t):
        q = self.segs[0][1]
        for (t0, q0, q1, T) in self.segs:
            if t < t0:
                break
            q = q1 if t >= t0 + T else q0 + (q1 - q0) * self._profile((t - t0) / T, T)
        return np.array(q, dtype=float)

    @staticmethod
    def _profile(x, T):
        ta = min(T_ACC, T / 2) / T  # normalized trapezoid
        a = 1 / (ta * (1 - ta))
        if x < ta:
            return 0.5 * a * x * x
        if x > 1 - ta:
            return 1 - 0.5 * a * (1 - x) ** 2
        return 0.5 * a * ta * ta + a * ta * (x - ta)

    def get_q(self):
        return self.q_at(_VCLOCK.t)

    def move_to_q(self, q):
        q = np.asarray(q, dtype=float)
        if not self.in_limits(q):
            raise ValueError(f"q out of limits: {q}")
        t0 = _VCLOCK.t + CMD_LATENCY
        q0 = self.q_at(t0)
        T = float(np.max(np.abs(q - q0) / (VMAX * self.speed))) + T_ACC
        self.segs.append((t0, q0, q, T))

    def in_motion(self):
        t0, _, _, T = self.segs[-1]
        return _VCLOCK.t < t0 + T

    def wait_for_motion_stop(self):
        t0, _, _, T = self.segs[-1]
        _VCLOCK.sleep(t0 + T - _VCLOCK.t)

    def grab_image(self, timeout=10000):
        t = _VCLOCK.t
        img = self.world.render(t)
        _VCLOCK.sleep(FRAME_TIME)
        return img
