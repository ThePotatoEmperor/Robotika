#!/usr/bin/env python
"""
ROB1 semestral work - variant A2 (straight rod on the rotating turntable, both directions).

AUTOMATIC mode (the demonstration):
    python main.py

TESTING mode (setup, calibration and checks - see README.md for the order):
    python main.py --testing jog          record heights / poses by hand
    python main.py --testing calibrate    camera calibration with the hoop (plate removed)
    python main.py --testing drop-test    measure the descent time (plate removed)
    python main.py --testing camera       one annotated camera image
    python main.py --testing track        rotation estimate + prediction accuracy
    python main.py --testing dry-run      full synchronized motion, but staying above the rod
    python main.py --testing auto         the real attempt with extra output

Add --sim to any of them to run against the built-in simulator instead of the robot.
"""
import argparse
import traceback

import config as C
from robot_iface import Arm, make_robot, shutdown
from station import Station

TOOLS = ["jog", "calibrate", "drop-test", "camera", "track", "dry-run", "auto"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--testing", choices=TOOLS, metavar="TOOL", help=" | ".join(TOOLS))
    ap.add_argument("--sim", action="store_true", help="use the simulator instead of the robot")
    ap.add_argument("--direction", choices=["ccw", "cw", "stop"], default="ccw",
                    help="simulator only: turntable direction")
    ap.add_argument("--sim-board", type=float, nargs=2, metavar=("DX", "DY"),
                    help="simulator only: plate position relative to the turntable centre [m]")
    ap.add_argument("--sim-table", type=float, nargs=2, metavar=("X", "Y"),
                    help="simulator only: turntable centre in robot coordinates [m]")
    ap.add_argument("--q", type=float, nargs=4, help="camera tool: move here first")
    ap.add_argument("--no-show", action="store_true", help="do not open image windows")
    args = ap.parse_args()

    sim_opts = {}
    if args.sim:
        import sim as S
        sim_opts = dict(direction=args.direction)
        if args.sim_board:
            sim_opts["board_offset"] = tuple(args.sim_board)
        if args.sim_table:
            sim_opts["table_center"] = tuple(args.sim_table)
        S.install_clock()
    st = Station.load(C.SIM_STATION_FILE if args.sim else C.STATION_FILE)
    if args.sim:
        import sim as S
        S.bootstrap_station(st)  # simulates the `jog` step with ground-truth values

    robot, world = make_robot(args.sim, sim_opts)
    arm = Arm(robot, st.cam_latency)
    show = not (args.no_show or args.sim)
    ok = False
    try:
        tool = args.testing or "auto"
        if tool == "jog":
            from testing_tools import jog
            jog(arm, st)
        elif tool == "calibrate":
            from testing_tools import calibrate
            calibrate(arm, st, sim=args.sim, show=show)
        elif tool == "drop-test":
            from testing_tools import drop_test
            drop_test(arm, st, sim=args.sim)
        elif tool == "camera":
            from testing_tools import camera_view
            camera_view(arm, st, args.q, show=show)
        elif tool == "track":
            from testing_tools import track_test
            track_test(arm, st, show=show)
        elif tool in ("dry-run", "auto"):
            from run_a2 import run_a2
            ok = run_a2(arm, st, dry=(tool == "dry-run"), show=show)
    except KeyboardInterrupt:
        print("Interrupted")
    except SystemExit as e:
        print(e)
    except Exception:
        traceback.print_exc()
    finally:
        try:
            if st.z_touch is not None:
                arm.move_up_to(st.heights().safe)  # never go home with the hoop low
        except Exception:
            pass
        if world is not None:
            print(world.report())
        shutdown(robot)
    return ok


if __name__ == "__main__":
    main()
