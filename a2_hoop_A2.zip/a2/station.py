"""
Station-specific measured data (station_calib.json) + derived heights + camera model.

All robot coordinates are FLANGE coordinates as returned by robot.fk() (x, y, z, phi).
The hoop sits at a fixed offset from the flange; as long as phi stays the same as during
calibration, that offset is constant and the camera calibration absorbs it. That is why
the hoop orientation `phi` is stored here and used for every hoop motion.
"""
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional

import numpy as np
import cv2

import config as C


@dataclass
class Station:
    path: str = C.STATION_FILE
    # measured with `--testing jog`
    z_touch: Optional[float] = None          # flange z when the hoop rests on the plate
    phi: Optional[float] = None              # hoop orientation used for all hoop motions
    q_ref: Optional[List[float]] = None      # hoop roughly above the turntable centre
    q_observe: Optional[List[float]] = None  # hoop out of the camera view
    # measured with `--testing calibrate`
    H_low: Optional[List[List[float]]] = None
    H_high: Optional[List[List[float]]] = None
    z_low: Optional[float] = None
    z_high: Optional[float] = None
    image_size: Optional[List[int]] = None   # (w, h)
    # measured with `--testing drop-test`
    drop_time: float = C.DROP_TIME
    lift_time: float = C.LIFT_TIME
    cmd_latency: float = C.CMD_LATENCY
    cam_latency: float = C.CAMERA_LATENCY

    @classmethod
    def load(cls, path) -> "Station":
        p = Path(path)
        if not p.exists():
            return cls(path=str(path))
        d = json.loads(p.read_text())
        d["path"] = str(path)
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})

    def save(self):
        d = asdict(self)
        d.pop("path")
        Path(self.path).write_text(json.dumps(d, indent=2))
        print(f"[saved {self.path}]")

    # ------------------------------------------------------------------ checks
    def missing(self, *names) -> List[str]:
        return [n for n in names if getattr(self, n) is None]

    def require(self, *names):
        m = self.missing(*names)
        if m:
            hint = {
                "z_touch": "--testing jog  (lower the hoop onto the plate, type 'touch')",
                "phi": "--testing jog  (type 'ref' with the hoop over the turntable)",
                "q_ref": "--testing jog  (type 'ref')",
                "q_observe": "--testing jog  (type 'observe'), or keep the default",
                "H_low": "--testing calibrate", "H_high": "--testing calibrate",
                "z_low": "--testing calibrate", "z_high": "--testing calibrate",
            }
            lines = "\n".join(f"  {n:10s} -> {hint.get(n, '')}" for n in m)
            raise SystemExit(f"Station data missing in {self.path}:\n{lines}")

    @property
    def observe_q(self):
        return self.q_observe if self.q_observe is not None else C.Q_OBSERVE_DEFAULT

    def heights(self) -> "Heights":
        self.require("z_touch")
        return Heights(self.z_touch)

    def camera(self) -> "CameraModel":
        self.require("H_low", "H_high", "z_low", "z_high")
        return CameraModel(np.array(self.H_low), self.z_low, np.array(self.H_high), self.z_high,
                           self.image_size)


@dataclass
class Heights:
    """Flange z values for the important hoop heights (assumes fk z grows upwards)."""
    z_touch: float

    def __post_init__(self):
        self.board = self.z_touch - C.HOOP_THICK / 2            # hoop centre at plate top
        self.rod_top = self.board + C.ROD_FOOT + C.ROD_HEIGHT    # hoop centre at rod top
        self.safe = self.rod_top + C.HOOP_THICK / 2 + C.CLEARANCE_ABOVE_ROD
        self.final = self.board + C.FINAL_ABOVE_BOARD

    def __str__(self):
        return (f"plate {self.board:.4f}  rod top {self.rod_top:.4f}  hover {self.safe:.4f}  "
                f"final {self.final:.4f}  (flange z, m)")


class CameraModel:
    """
    Two-plane camera model. H_low / H_high map image -> flange (x, y) for a hoop at flange
    height z_low / z_high. For a pinhole camera every pixel is a ray, and the two planes
    give two points on it, so the point at ANY height is a linear interpolation:

        P(z) = A + (z - z_low) / (z_high - z_low) * (B - A)

    This is exact (no need to recalibrate when the hoop or the plate is at another height).
    """

    def __init__(self, H_low, z_low, H_high, z_high, image_size=None):
        self.H_low, self.z_low = H_low, z_low
        self.H_high, self.z_high = H_high, z_high
        self.image_size = image_size or (1920, 1200)

    @staticmethod
    def _apply(H, pts):
        pts = np.asarray(pts, np.float64).reshape(-1, 1, 2)
        return cv2.perspectiveTransform(pts, H).reshape(-1, 2)

    def to_plane(self, uv, z) -> np.ndarray:
        """image (u, v) -> flange (x, y) for a point at flange height z. Returns (N, 2)."""
        A = self._apply(self.H_low, uv)
        B = self._apply(self.H_high, uv)
        s = (z - self.z_low) / (self.z_high - self.z_low)
        return A + s * (B - A)

    def plane_homography(self, z) -> np.ndarray:
        """Homography image -> plane at height z (for drawing / inverse mapping)."""
        w, h = self.image_size
        uu, vv = np.meshgrid(np.linspace(0, w, 6), np.linspace(0, h, 6))
        uv = np.column_stack([uu.ravel(), vv.ravel()])
        H, _ = cv2.findHomography(uv, self.to_plane(uv, z))
        return H

    def to_image(self, xy, z) -> np.ndarray:
        """flange (x, y) at height z -> image (u, v). Returns (N, 2)."""
        return self._apply(np.linalg.inv(self.plane_homography(z)), xy)
