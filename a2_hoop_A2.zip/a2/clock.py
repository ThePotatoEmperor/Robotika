"""
Single time source for everything. The real robot uses wall time; the simulator swaps in
a virtual clock so a 60 s experiment runs in a fraction of a second.
"""
import time


class RealClock:
    def now(self) -> float:
        return time.monotonic()

    def sleep(self, dt: float):
        if dt > 0:
            time.sleep(dt)


_clock = RealClock()


def set_clock(c):
    global _clock
    _clock = c


def now() -> float:
    return _clock.now()


def sleep(dt: float):
    _clock.sleep(dt)


def sleep_until(t: float):
    _clock.sleep(t - _clock.now())
