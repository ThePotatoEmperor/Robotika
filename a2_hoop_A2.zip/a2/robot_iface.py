"""
Thin wrapper around the robot driver (ctu_bosch_sr450.RobotBosch or the simulator).

- IK results are always verified with FK, so the code does not depend on the exact
  ik()/ik_xyz() signature of the driver version.
- Of several IK solutions the one closest to a reference configuration is used, so the
  arm never flips elbow between hover and drop.
- grab() returns the image together with its (estimated) capture time.
"""
from typing import Optional

import numpy as np

import clock
import config as C


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


class Arm:
    def __init__(self, robot, cam_latency=C.CAMERA_LATENCY):
        self.robot = robot
        self.cam_latency = cam_latency

    # ------------------------------------------------------------- kinematics
    def q(self) -> np.ndarray:
        return np.asarray(self.robot.get_q(), dtype=float)

    def fk(self, q=None):
        q = self.q() if q is None else q
        x, y, z, phi = self.robot.fk(np.asarray(q, dtype=float))
        return float(x), float(y), float(z), float(phi)

    def _raw_ik(self, x, y, z, phi):
        r, sols = self.robot, []
        if hasattr(r, "ik_xyz"):
            try:
                sols += list(r.ik_xyz(x, y, z, phi))
            except TypeError:
                pass
        try:
            sols += list(r.ik(x, y, z, phi))
        except TypeError:
            sols += list(r.ik([x, y, z, phi]))
        return [np.asarray(s, dtype=float) for s in sols]

    def ik_near(self, x, y, z, phi, q_ref=None) -> Optional[np.ndarray]:
        """Valid IK solution (in limits, FK matches the request) closest to q_ref."""
        q_ref = self.q() if q_ref is None else np.asarray(q_ref, dtype=float)
        good = []
        for s in self._raw_ik(x, y, z, phi):
            if hasattr(self.robot, "in_limits") and not self.robot.in_limits(s):
                continue
            fx, fy, fz, fphi = self.fk(s)
            if np.hypot(fx - x, fy - y) > 1e-3 or abs(fz - z) > 1e-3 or abs(wrap(fphi - phi)) > 1e-2:
                continue
            good.append(s)
        if not good:
            return None
        w = np.array([1.0, 1.0, 1.0, 0.3])
        return min(good, key=lambda s: float(np.sum(w * np.abs(s - q_ref))))

    # ----------------------------------------------------------------- motion
    def move(self, q, wait=True):
        self.robot.move_to_q(list(np.asarray(q, dtype=float)))
        if wait:
            self.robot.wait_for_motion_stop()

    def move_xyz(self, x, y, z, phi, wait=True, q_ref=None) -> bool:
        q = self.ik_near(x, y, z, phi, q_ref)
        if q is None:
            return False
        self.move(q, wait)
        return True

    def move_up_to(self, z) -> bool:
        """Vertical move only (same x, y, phi). Never moves down."""
        x, y, z0, phi = self.fk()
        if z0 >= z - 1e-4:
            return True
        return self.move_xyz(x, y, z, phi)

    # ----------------------------------------------------------------- camera
    def grab(self):
        img = self.robot.grab_image()
        t = clock.now() - self.cam_latency
        return img, t


def make_robot(sim=False, sim_options=None):
    """Create + initialize the robot (or the simulator). Returns (robot, world_or_None)."""
    if sim:
        import sim as S
        world = S.SimWorld(**(sim_options or {}))
        robot = S.SimRobot(world)
        robot.initialize()
        return robot, world
    from ctu_bosch_sr450 import RobotBosch
    robot = RobotBosch()
    robot.initialize()
    if C.SPEED_FRACTION is not None:
        robot.set_speed_relative(C.SPEED_FRACTION)
    return robot, None


def shutdown(robot):
    try:
        if hasattr(robot, "soft_home"):
            robot.soft_home()
            if hasattr(robot, "wait_for_motion_stop"):
                robot.wait_for_motion_stop()
    finally:
        robot.close()
