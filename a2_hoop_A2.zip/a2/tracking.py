"""
Rotation tracking of the base plate on the turntable.

Every frame gives the plate centre p_i (flange xy at plate height) and the plate angle
theta_i (direction marker A -> marker B) at time t_i.

  1. theta(t) = theta_ref + omega * (t - t_ref)     (line fit; sign of omega = direction)
  2. p_i = c + R(theta_i - theta_ref) d             (linear least squares for c and d)
     c = turntable centre, d = plate centre relative to c at t_ref.

The rod stands at the plate centre, so rod(t) = c + R(omega (t - t_ref)) d.
Using the plate ANGLE (not only the position) makes it work even when the rod is close to
the turntable centre, and it handles both directions of rotation automatically.
"""
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

import clock
import config as C
from vision import BoardLocator, detect_rod_top


def rot(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s], [s, c]])


@dataclass
class RotationModel:
    t_ref: float
    theta_ref: float
    omega: float                 # rad/s, > 0 = counter-clockwise seen from above (z up)
    c: np.ndarray                # turntable centre (flange xy)
    d: np.ndarray                # plate centre - c at t_ref
    static: bool
    span: float                  # rotation observed during fitting [rad]
    rms_pos: float               # position residual [m]
    rms_ang: float               # angle residual [rad]
    n: int

    @classmethod
    def fit(cls, obs: List[Tuple[float, np.ndarray, float]]) -> Optional["RotationModel"]:
        if len(obs) < 3:
            return None
        t = np.array([o[0] for o in obs])
        p = np.array([o[1] for o in obs])
        th = np.unwrap(np.array([o[2] for o in obs]))
        t_ref = float(t.mean())
        omega, theta_ref = np.polyfit(t - t_ref, th, 1)
        rms_ang = float(np.sqrt(np.mean((theta_ref + omega * (t - t_ref) - th) ** 2)))
        span = float(abs(th.max() - th.min()))

        if abs(np.degrees(omega)) < C.STATIC_OMEGA_DEG:
            c = p.mean(0)
            res = np.linalg.norm(p - c, axis=1)
            return cls(t_ref, float(theta_ref), 0.0, c, np.zeros(2), True, span,
                       float(np.sqrt(np.mean(res ** 2))), rms_ang, len(obs))

        A, b = [], []
        for ti, pi in zip(t, p):
            co, si = np.cos(omega * (ti - t_ref)), np.sin(omega * (ti - t_ref))
            A += [[1, 0, co, -si], [0, 1, si, co]]
            b += [pi[0], pi[1]]
        sol, *_ = np.linalg.lstsq(np.array(A), np.array(b), rcond=None)
        c, d = sol[:2], sol[2:]
        m = cls(t_ref, float(theta_ref), float(omega), c, d, False, span, 0.0, rms_ang, len(obs))
        res = np.linalg.norm(np.array([m.rod(ti) for ti in t]) - p, axis=1)
        m.rms_pos = float(np.sqrt(np.mean(res ** 2)))
        return m

    def good_enough(self) -> bool:
        return self.static or self.span >= np.radians(C.MIN_ANGLE_SPAN_DEG)

    # ------------------------------------------------------------ prediction
    def rod(self, t) -> np.ndarray:
        if self.static:
            return self.c.copy()
        return self.c + rot(self.omega * (t - self.t_ref)) @ self.d

    def angle(self, t) -> float:
        return self.theta_ref + self.omega * (t - self.t_ref)

    @property
    def radius(self) -> float:
        return float(np.linalg.norm(self.d))

    @property
    def period(self) -> float:
        return float("inf") if self.static or self.omega == 0 else 2 * np.pi / abs(self.omega)

    def direction(self) -> str:
        if self.static:
            return "not rotating"
        return "counter-clockwise" if self.omega > 0 else "clockwise"

    def describe(self) -> str:
        if self.static:
            return (f"Turntable stopped. Rod at ({self.c[0]:.4f}, {self.c[1]:.4f}) m, "
                    f"position noise {self.rms_pos * 1000:.1f} mm, {self.n} frames")
        return (f"Rotation {self.direction()} (robot frame, z up), "
                f"{np.degrees(abs(self.omega)):.2f} deg/s = {self.period:.1f} s per turn\n"
                f"  turntable centre ({self.c[0]:.4f}, {self.c[1]:.4f}) m, rod circle radius "
                f"{self.radius * 1000:.1f} mm\n"
                f"  fit: {self.n} frames, {np.degrees(self.span):.1f} deg observed, "
                f"residual {self.rms_pos * 1000:.2f} mm / {np.degrees(self.rms_ang):.2f} deg")


def observe(arm, cam, z_plane, duration=C.OBSERVE_TIME, max_time=C.OBSERVE_MAX_TIME, verbose=True,
            locator=None):
    """
    Grab frames for `duration` seconds (longer if the rotation span is still too small).
    Returns (model or None, observations, last image, last board detection).
    """
    locator = locator if locator is not None else BoardLocator()
    frames, last_img, last_board = [], None, None   # (t, plate-from-pair or None, marker poses)
    rod_frames = []   # fallback: (t, rod xy from the orange rod top, marker poses)
    z_rod_top = z_plane + C.ROD_FOOT + C.ROD_HEIGHT

    def build_obs():
        """Pair frames directly; single-marker frames (e.g. the rod hides a corner of the
        other marker) via the offsets learned from the pair frames - also older frames."""
        out, n_single = [], 0
        for t, b, poses in frames:
            if b is None:
                b = locator.resolve(poses)
                n_single += b is not None
            if b is not None:
                out.append((t, b["center"], b["angle"]))
        if len(out) < 3 and rod_frames:
            # no marker pair ever seen (e.g. table stopped with the rod over a marker):
            # position from the rod top itself, rotation from one marker's own angle
            ids = [i for _, _, poses in rod_frames for i in poses]
            mid = max(set(ids), key=ids.count)
            out = [(t, xy, poses[mid][1]) for t, xy, poses in rod_frames if mid in poses]
            n_single = -len(out)  # negative = rod-top fallback (for the printout)
        return out, n_single

    t0 = clock.now()
    while True:
        img, t = arm.grab()
        if img is not None:
            last_img = img
            b, poses, markers = locator.measure(img, cam, z_plane)
            if b is not None or poses:
                frames.append((t, b, poses))
            if b is None and poses and locator.resolve(poses) is None:
                rod = detect_rod_top(img, cam, z_rod_top)
                if rod is not None:
                    rod_frames.append((t, rod["xy"], poses))
            last_board = b if b is not None else (locator.resolve(poses, markers) or last_board)
        el = clock.now() - t0
        if el >= duration:
            obs, _ = build_obs()
            if len(obs) >= 8:
                m = RotationModel.fit(obs)
                if m is not None and m.good_enough():
                    break
        if el >= max_time:
            break
    obs, n_single = build_obs()
    m = RotationModel.fit(obs)
    spacing = [b["spacing_err"] for _, b, _ in frames if b is not None]
    if verbose:
        how = (f"{-n_single} from the rod top + one marker (fallback)" if n_single < 0
               else f"{n_single} from one marker")
        print(f"Observed {len(obs)} plate detections ({how}) in {clock.now() - t0:.1f} s")
        if spacing:
            print(f"  marker spacing error {np.mean(spacing) * 1000:+.1f} mm "
                  f"(checks calibration + plate height; should be within a few mm)")
    if m is not None and not m.good_enough():
        if verbose:
            print("  rotation span too small to fit the circle reliably")
        m = None
    return m, obs, last_img, last_board
