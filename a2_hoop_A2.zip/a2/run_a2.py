"""
Variant A2: straight rod anywhere on the rotating turntable, both rotation directions.

    observe -> fit rotation -> reachability check -> hover above the rod's future position
    -> wait -> synchronized drop -> (lift off) -> back to the observe pose

dry=True does the same synchronized motion, but stays above the rod the whole time
(safe check of timing and calibration).
"""
import cv2
import numpy as np

import clock
import config as C
import vision as V
from planner import plan_intercept, reachable_fraction
from tracking import observe


def draw_plan(img, cam, H, model, board=None, plan=None, lines_extra=()):
    vis = img.copy()
    s = V.scale_of(vis)
    if board is not None:
        V.draw_markers(vis, board["markers"])
    if model is not None:
        if not model.static:
            ts = model.t_ref + np.linspace(0, model.period, 120)
            circ = cam.to_image(np.array([model.rod(t) for t in ts]), H.board).astype(np.int32)
            cv2.polylines(vis, [circ], True, YELLOW_DIM, max(2, int(2 * s)), cv2.LINE_AA)
            V.draw_cross(vis, cam.to_image(model.c, H.board)[0], V.WHITE, 15, 2)
        now_uv = cam.to_image(model.rod(clock.now()), H.board)[0]
        cv2.circle(vis, (int(now_uv[0]), int(now_uv[1])), int(10 * s), V.ORANGE, -1, cv2.LINE_AA)
    if plan is not None:
        a = cam.to_image(plan.p_hover, H.board)[0]
        b = cam.to_image(plan.p_final, H.board)[0]
        cv2.arrowedLine(vis, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), V.GREEN,
                        max(2, int(4 * s)), cv2.LINE_AA, tipLength=0.3)
        r_px = np.linalg.norm(cam.to_image(plan.p_hover + [C.HOOP_R_IN, 0], H.board)[0] - a)
        cv2.circle(vis, (int(a[0]), int(a[1])), int(r_px), V.GREEN, max(2, int(3 * s)), cv2.LINE_AA)
    lines = [("A2: rod on rotating turntable", V.WHITE)]
    if model is not None:
        if model.static:
            lines.append(("turntable stopped", V.GRAY))
        else:
            lines.append((f"{model.direction()}, {np.degrees(abs(model.omega)):.2f} deg/s, "
                          f"{model.period:.1f} s/turn", V.CYAN))
            lines.append((f"rod circle radius {model.radius * 1000:.0f} mm", V.GRAY))
    lines += list(lines_extra)
    legend = [("yellow: rod path   orange dot: rod now", V.GRAY)]
    if plan is not None:
        legend.append(("green: hoop at hover, arrow = drop", V.GREEN))
    lines += legend
    V.text_box(vis, lines, (int(20 * s), int(20 * s)), border=V.WHITE)
    return vis


YELLOW_DIM = (0, 200, 230)


def safe_observe_q(arm, st, H):
    """The observe pose, raised to hover height if it is lower (every motion apart from the
    final drop then happens above the rod top)."""
    q = list(st.observe_q)
    x, y, z, phi = arm.fk(q)
    if z >= H.safe:
        return q
    q2 = arm.ik_near(x, y, H.safe, phi, q)
    if q2 is None:
        print("WARNING: observe pose cannot be raised to hover height - using it as is")
        return q
    return list(q2)


def run_a2(arm, st, dry=False, show=True, out="a2_result.png"):
    st.require("z_touch", "phi", "H_low", "H_high", "z_low", "z_high")
    cam, H, phi = st.camera(), st.heights(), st.phi
    t_task = clock.now()
    tag = "DRY RUN" if dry else "A2"
    print(f"=== {tag} ===\n{H}")

    # 1) observe the plate (hoop out of the view)
    arm.move_up_to(H.safe)
    arm.move(safe_observe_q(arm, st, H))
    from vision import BoardLocator
    locator = BoardLocator()
    model, obs, img, board = observe(arm, cam, H.board, locator=locator)
    if model is None:
        print("ERROR: could not estimate the plate motion (are both markers visible?)")
        if img is not None:
            cv2.imwrite(out, draw_plan(img, cam, H, None, board, None, [("plate NOT tracked", V.RED)]))
        return False
    print(model.describe())

    # descent motion = measured drop time minus the command latency (motion starts later)
    motion_time = max(st.drop_time - st.cmd_latency, 0.2)

    # 2) reachability, decided BEFORE any motion towards the rod
    frac = reachable_fraction(arm, model, H, phi, arm.q())
    print(f"Reachable part of the rod's circle: {frac * 100:.0f} %")
    plan = plan_intercept(arm, model, H, phi, arm.q(), clock.now() + C.FIRST_MOVE_LEAD,
                          motion_time, dry)
    if plan is None:
        print("UNREACHABLE: the robot cannot safely reach the rod anywhere on its path. "
              "Not starting the motion.")
        cv2.imwrite(out, draw_plan(img, cam, H, model, board, None, [("UNREACHABLE", V.RED)]))
        if show:
            V.show(cv2.imread(out), "A2 result")
        return False
    cv2.imwrite(out, draw_plan(img, cam, H, model, board, plan))

    # 3) go to the hover point (re-plan if we arrive too late)
    arm.move_up_to(plan.z_hover)
    for attempt in range(8):
        arm.move(plan.q_hover)
        slack = plan.t_start - st.cmd_latency - clock.now()
        if slack >= C.MIN_SLACK:
            break
        print(f"  arrived {-slack:.2f} s too late -> re-planning a bit further along the path")
        plan = plan_intercept(arm, model, H, phi, arm.q(), clock.now() + C.REPOSITION_LEAD,
                              motion_time, dry)
        if plan is None:
            print("ABORT: no reachable intercept left")
            return False
    else:
        print("ABORT: could not get ahead of the rod")
        return False
    print(f"  hovering, waiting {slack:.2f} s for the rod")

    # 4) synchronized drop
    clock.sleep_until(plan.t_start - st.cmd_latency)
    t_cmd = clock.now()
    arm.move(plan.q_final)
    t_done = clock.now()
    x, y, z, _ = arm.fk()
    above = z - H.board
    rod_now = model.rod(t_done)
    off = np.hypot(x - rod_now[0], y - rod_now[1])
    print(f"  drop took {t_done - t_cmd:.2f} s (measured before: {st.drop_time:.2f} s)")
    result = [("DRY RUN done" if dry else "HOOP DOWN", V.GREEN),
              (f"hoop {above * 100:.1f} cm above plate", V.WHITE)]
    if not dry:
        print(f"  hoop centre {above * 100:.1f} cm above the plate, predicted rod offset "
              f"{off * 1000:.1f} mm (limit ~{(C.HOOP_R_IN - C.ROD_WIDTH / np.sqrt(2)) * 1000:.0f} mm)")
        result.append((f"predicted hoop-rod offset {off * 1000:.1f} mm", V.WHITE))
    if dry:
        # the dry "drop" is a short move; wait until the real drop would have ended
        clock.sleep_until(plan.t_start + motion_time)
        img2, t2 = arm.grab()
        rod_pred = model.rod(t2)
        x2, y2, z2, _ = arm.fk()
        print(f"  hoop vs PREDICTED rod at the end of the drop: "
              f"{np.hypot(x2 - rod_pred[0], y2 - rod_pred[1]) * 1000:.1f} mm")
        # measured purely in the image: orange rod top vs hoop ring, each at its own height
        rod = V.detect_rod_top(img2, cam, H.rod_top) if img2 is not None else None
        hoop = V.detect_hoop(img2) if img2 is not None else None
        if rod is not None and hoop is not None:
            hoop_xy = cam.to_plane(hoop["center"], z2)[0]
            err = np.linalg.norm(hoop_xy - rod["xy"])
            print(f"  hoop vs MEASURED rod top (camera): {err * 1000:.1f} mm "
                  f"(limit ~{(C.HOOP_R_IN - C.ROD_WIDTH / np.sqrt(2)) * 1000:.0f} mm)")
            result.append((f"camera: hoop-rod offset {err * 1000:.1f} mm", V.YELLOW))
            dbg = img2.copy()
            V.draw_hoop(dbg, hoop)
            V.draw_cross(dbg, rod["uv"], V.ORANGE)
            V.text_box(dbg, [("DRY RUN CHECK", V.WHITE),
                             (f"hoop-rod offset {err * 1000:.1f} mm", V.YELLOW)], (20, 20), border=V.WHITE)
            cv2.imwrite("dry_run_check.png", dbg)
        else:
            print(f"  camera check not possible (rod top {'found' if rod else 'NOT found'}, "
                  f"hoop {'found' if hoop else 'NOT found'})")
    else:
        ok = above <= 0.04
        print("SUCCESS: hoop is over the rod and below 4 cm." if ok else "WARNING: hoop not low enough")

    # 5) lift off the rod (following it) and go back
    if dry or C.LIFT_AFTER_SUCCESS:
        p = model.rod(clock.now() + st.lift_time)
        arm.move_xyz(p[0], p[1], max(H.safe, plan.z_hover), phi)
    print(f"Total {clock.now() - t_task:.1f} s")
    vis = draw_plan(img, cam, H, model, board, plan, result)
    cv2.imwrite(out, vis)
    print(f"[overlay saved to {out}]")
    if show:
        V.show(vis, "A2 result")
    return True
