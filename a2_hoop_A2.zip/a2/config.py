"""
All tunable constants in one place. Units: metres, seconds, radians, pixels.

Geometry comes from the drawings in https://github.com/pilcsimo/ROB1-2025-hw (mm -> m).
Values that must be MEASURED at the station (heights, poses, camera calibration) are NOT
here - they live in station_calib.json and are written by the testing tools (jog, calibrate,
drop-test).
"""
import numpy as np
import cv2

# --------------------------------------------------------------------------------------
# Geometry (ROB1-2025-hw drawings)
# --------------------------------------------------------------------------------------
BOARD_SIZE = 0.125                 # base plate 125 x 125 mm
MARKER_SIZE = 0.040                # ArUco 40 x 40 mm
MARKER_OFFSET = 0.0375             # marker centre from plate centre, along both plate axes
MARKER_SPACING = 2 * np.sqrt(2) * MARKER_OFFSET   # 106.1 mm between the two marker centres
ROD_HEIGHT = 0.200                 # puzzle A rod, 10 x 10 x 200 mm, at the plate centre
ROD_FOOT = 0.0025                  # foot plate thickness under the rod
ROD_WIDTH = 0.010
HOOP_R_IN = 0.030                  # hoop inner radius (Ø60)
HOOP_R_OUT = 0.0348                # hoop outer radius (Ø69.6)
HOOP_THICK = 0.0066                # hoop ring height

# --------------------------------------------------------------------------------------
# Task
# --------------------------------------------------------------------------------------
FINAL_ABOVE_BOARD = 0.020          # hoop centre above the plate at the end (rule: < 0.04)
CLEARANCE_ABOVE_ROD = 0.030        # hoop bottom above the rod top while hovering
DRY_RUN_EXTRA = 0.030              # dry-run hovers this much higher still

# --------------------------------------------------------------------------------------
# Timing / tracking / planning
# --------------------------------------------------------------------------------------
OBSERVE_TIME = 6.0                 # how long to watch the rotating plate before planning
OBSERVE_MAX_TIME = 20.0            # give up if the plate is not seen well by then
MIN_ANGLE_SPAN_DEG = 12.0          # need at least this much rotation to fit the circle
STATIC_OMEGA_DEG = 0.3             # |omega| below this [deg/s] = turntable treated as stopped
FIRST_MOVE_LEAD = 4.0              # time reserved for the first move to the hover point [s]
REPOSITION_LEAD = 1.5              # time reserved for a short correction move [s]
MIN_SLACK = 0.10                   # must arrive at the hover point at least this early [s]
PLAN_STEP = 0.05                   # planner time resolution [s]
MAX_JOINT_SWING = 0.6              # hover->final must not swing q1/q2 more than this [rad]
CAMERA_LATENCY = 0.03              # image timestamp = grab return time - this (default)
CMD_LATENCY = 0.05                 # move_to_q call -> motion start (default, drop-test measures)
DROP_TIME = 1.5                    # descent duration default (drop-test measures it)
LIFT_TIME = 1.5
SPEED_FRACTION = None              # e.g. 0.5 to slow the robot down, None = driver default
LIFT_AFTER_SUCCESS = True          # lift the hoop off the rod after the task is fulfilled

# --------------------------------------------------------------------------------------
# Camera calibration (testing: calibrate)
# --------------------------------------------------------------------------------------
CALIB_GRID_N = 3                   # N x N hoop positions per height
CALIB_GRID_STEP = 0.05             # grid spacing [m] around the reference pose
CALIB_Z_LOW_ABOVE_TOUCH = 0.010    # low plane: hoop 1 cm above plate height
CALIB_Z_HIGH_ABOVE_TOUCH = 0.150   # high plane: 15 cm higher (lower it if out of reach)
SETTLE_TIME = 0.3                  # wait after a move before grabbing an image

# --------------------------------------------------------------------------------------
# Vision
# --------------------------------------------------------------------------------------
ARUCO_DICT = cv2.aruco.DICT_4X4_1000
HOOP_MIN_R = 50                    # hoop radius range in the image [px]
HOOP_MAX_R = 450
HOOP_DARK = 120                    # gray level below which a pixel counts as hoop
HOUGH_PARAM2 = 40
ROD_HSV_LO = (170, 140, 80)        # orange/red rod in HSV: hue 170..180 ...
ROD_HSV_HI = (180, 255, 255)
ROD_HSV_LO2 = (0, 140, 80)         # ... and hue 0..ROD_HUE_MAX (hue wraps around)
ROD_HUE_MAX = 22
ROD_MIN_AREA = 40                  # px

# --------------------------------------------------------------------------------------
# Defaults / files
# --------------------------------------------------------------------------------------
Q_OBSERVE_DEFAULT = [0.9, -0.6, 0.0, 0.2]   # your ArUco pose: hoop out of the camera view
STATION_FILE = "station_calib.json"
SIM_STATION_FILE = "station_calib_sim.json"
