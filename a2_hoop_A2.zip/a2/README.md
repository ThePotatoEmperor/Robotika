# ROB1 – variant A2: hoop over a rod on the rotating turntable

The rod (puzzle A) stands anywhere on the turntable, the turntable rotates (either direction,
+2 bonus points), and the Bosch robot puts the hoop over the rod down to less than 4 cm above
the plate. If the rod cannot be reached, the program says so **before** moving towards it.

## How it works

1. **Camera model (two planes).** The hoop is moved over a 3×3 grid at two heights; the
   camera sees it, `fk()` says where the flange is. This gives two homographies
   image → robot XY. Every pixel is a ray, the two planes give two points on it, so the
   robot XY of an image point at **any height** is a linear interpolation (exact for a
   pinhole camera). This means no recalibration when the hoop or plate is at another height.
2. **Plate tracking.** From the observe pose (hoop out of view) the two ArUco markers are
   tracked for ~6 s. Plate angle θ(t) = θ₀ + ω t (the sign of ω is the direction), and the plate
   centre (= rod) p(t) = c + R(ω t) d by least squares. If one marker is hidden (the tall
   rod leans over it in perspective, or the arm), the plate is located from the other one.
3. **Intercept plan.** Search the first time T at which both the hover pose above the rod
   at T and the final pose at T + drop time are reachable (IK, joint limits, no elbow flip).
   None in 1.25 turns → **UNREACHABLE**, nothing moves.
4. **Execution.** The hoop goes up first and then to the hover point 3 cm above the rod top.
   It waits there until the rod passes underneath, then drops in one coordinated move to
   where the rod will be at the end of the drop. The rod can be up to ~23 mm off-centre in the hoop
   (hoop Ø60, rod 10×10 mm). Then it lifts off following the rod.

All motions except the final drop happen above the rod top.

## Files

| file | what |
|---|---|
| `main.py` | entry point: automatic mode and `--testing` tools, `--sim` |
| `config.py` | all tunable constants (geometry from the drawings, timing, vision) |
| `station.py` | measured station data (`station_calib.json`), heights, camera model |
| `vision.py` | ArUco plate detection, hoop detection, rod-top detection, drawing |
| `tracking.py` | rotation estimation and prediction |
| `planner.py` | intercept planning + reachability |
| `run_a2.py` | the A2 attempt (and the dry run) |
| `robot_iface.py` | robot wrapper (IK verified by FK, image timestamps) |
| `testing_tools.py` | jog, calibrate, drop-test, camera, track |
| `sim.py` | simulator: robot, turntable, camera, collision referee |

## At the station (first time, ~20 min)

Run everything from this folder. Each tool saves into `station_calib.json`; once it is
complete, later sessions only need step 5–7 (redo 2–4 if the camera or table was moved).

1. **Camera check:** `python main.py --testing camera`
   Both markers should be found (cyan). Move the hoop into view (`--q ...`) and check it is
   detected (green ellipse); if not, adjust `HOOP_MIN_R/HOOP_MAX_R/HOOP_DARK` in `config.py`.
2. **Jog:** `python main.py --testing jog`
   - Move the hoop above the middle of the turntable with the orientation you want to use
     (handle pointing away from the robot is best), type `ref`. This fixes `phi` for good.
   - Lower it carefully until the hoop rests on the plate, type `touch`.
   - Put the hoop out of the camera view, type `observe` (your `[0.9, -0.6, 0, 0.2]` is the
     default otherwise).
3. **Calibrate:** `python main.py --testing calibrate`
   Remove the plate with the rod when asked. Check the printed errors (should be ~1 mm)
   and `calib_result.png`.
4. **Drop timing:** `python main.py --testing drop-test` (plate removed when asked).
5. **Tracking:** `python main.py --testing track` with the plate back and the turntable on.
   Check the printed values:
   - `marker spacing error` should be within a few mm. If not, `touch` or the calibration
     is off.
   - The direction and turn time should match what you see.
   - The `prediction error` should be a few mm.
6. **Dry run:** `python main.py --testing dry-run`
   The full synchronized motion, but 3 cm higher, so the hoop never goes down.
   The camera then measures the hoop-to-rod-top offset directly (`dry_run_check.png`).
   Should be well under 23 mm.
7. **Real attempt:** `python main.py` (or `--testing auto`). Overlay saved to `a2_result.png`.

## Simulator

Same commands with `--sim` (no windows), e.g.

```
python main.py --sim --testing calibrate
python main.py --sim --testing drop-test
python main.py --sim --testing track
python main.py --sim --direction cw
python main.py --sim --sim-board 0.08 0.03 --direction ccw
python main.py --sim --sim-table 0.60 0.22 --sim-board -0.03 0      # unreachable
```

At the end the simulator prints a referee verdict: collision, task fulfilled, and the
smallest rod-to-hoop clearance (22.9 mm = perfectly centred). Its numbers (arm, camera,
heights) are invented; it tests the logic, not the real station.

## Things to verify on the real robot (assumptions)

- `fk()` z grows upwards. `calibrate` checks this: the hoop must look bigger at the high
  plane, otherwise it stops.
- `ik()` / `ik_xyz()` signatures: the wrapper tries both and verifies every solution with `fk()`.
- The Z stroke must cover plate+2 cm up to rod top+3 cm (~21 cm of hoop travel). If IK fails
  for the hover height, lower `CLEARANCE_ABOVE_ROD` a little.
- The rod colour for the dry-run camera check: `ROD_HSV_*` in `config.py`.
- The turntable must rotate steadily (constant speed). A slow drift is fine, the
  observation is right before the attempt.

## For the report

- **Experiments:** `track` gives the prediction error. The simulator batch over plate
  positions and directions shows where it works, and `Reachable part of the rod's circle`
  shows which plate positions are reachable. You can build the required workspace map from
  that.
- **Failure modes covered:** markers occluded (single-marker tracking), late arrival
  (automatic re-plan further along the path), and unreachable (reported before motion).
