"""
Intercept planning.

Strategy: hover the hoop just above the rod top at the point where the rod WILL be at time
T, wait there until the rod arrives under the hoop, then drop in one coordinated move to
where the rod will be at T + drop_time. All joints start and stop together, so the hoop
moves along the (almost straight, few cm) chord of the rod's arc while descending.

Rod-hoop clearance is ~23 mm (hoop inner radius 30 mm, rod half-diagonal 7 mm), which
absorbs the small speed-profile mismatch and tracking error.
"""
from dataclasses import dataclass
from typing import Optional

import numpy as np

import config as C


@dataclass
class Plan:
    t_start: float           # when the drop command must be issued (+ cmd latency)
    p_hover: np.ndarray      # rod position at t_start
    p_final: np.ndarray      # rod position at t_start + drop_time
    q_hover: np.ndarray
    q_final: np.ndarray
    z_hover: float
    z_final: float


def plan_intercept(arm, model, heights, phi, q_from, t_earliest, drop_time,
                   dry=False, horizon=None) -> Optional[Plan]:
    """First feasible start time >= t_earliest (both poses reachable, no elbow flip)."""
    z_hover = heights.safe + (C.DRY_RUN_EXTRA if dry else 0.0)
    z_final = z_hover if dry else heights.final
    if horizon is None:
        horizon = 1.0 if model.static else min(1.25 * model.period, 120.0)
    for T in np.arange(t_earliest, t_earliest + horizon, C.PLAN_STEP):
        p0 = model.rod(T)
        p1 = model.rod(T + drop_time)
        qh = arm.ik_near(p0[0], p0[1], z_hover, phi, q_from)
        if qh is None:
            continue
        qf = arm.ik_near(p1[0], p1[1], z_final, phi, qh)
        if qf is None:
            continue
        if np.max(np.abs(qf[:2] - qh[:2])) > C.MAX_JOINT_SWING:
            continue
        return Plan(float(T), p0, p1, qh, qf, z_hover, z_final)
    return None


def reachable_fraction(arm, model, heights, phi, q_from, n=72) -> float:
    """Which part of the rod's circle is reachable at both hover and final height (report)."""
    if model.static:
        ts = [model.t_ref]
    else:
        ts = model.t_ref + np.linspace(0, model.period, n, endpoint=False)
    ok = 0
    for t in ts:
        p = model.rod(t)
        qh = arm.ik_near(p[0], p[1], heights.safe, phi, q_from)
        qf = qh is not None and arm.ik_near(p[0], p[1], heights.final, phi, qh) is not None
        ok += bool(qf)
    return ok / len(ts)
