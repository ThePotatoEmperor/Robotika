"""
Testing / calibration tools (main.py --testing <tool>).

  jog        move the robot by hand from the terminal, record z_touch / ref / observe pose
  calibrate  automatic two-height camera calibration with the hoop (plate removed)
  drop-test  measure how long the hover->final descent takes (+ command latency)
  camera     one image with markers, plate position and hoop detection drawn
  track      watch the rotating plate, print the rotation and how well it is predicted
"""
import cv2
import numpy as np

import clock
import config as C
import vision as V
from station import Heights
from tracking import observe

MAX_JOG = 0.05


def prompt(msg, sim=False):
    if sim:
        print(f"[sim] {msg} -> continuing automatically")
        return ""
    return input(f"{msg} ")


def park(arm, st):
    """Hoop up above rod height and out of the way (before the plate is put back)."""
    from run_a2 import safe_observe_q
    arm.move_up_to(st.heights().safe)
    arm.move(safe_observe_q(arm, st, st.heights()))


# ======================================================================================
def jog(arm, st):
    print("""Jog commands (metres / radians, steps limited to 5 cm):
  x 0.01 | y -0.01 | z -0.005 | phi 0.1   move relative in the base frame (keeps the rest)
  j1 0.05 ... j4 0.05                      move one joint relative
  p                                        print q and fk
  touch                                    save z_touch  (hoop resting on the plate)
  ref                                      save q_ref + phi (hoop above the turntable centre)
  observe                                  save q_observe (hoop out of the camera view)
  q                                        quit""")
    while True:
        try:
            cmd = input("jog> ").strip().split()
        except EOFError:
            break
        if not cmd:
            continue
        k = cmd[0]
        try:
            if k == "q":
                break
            if k == "p":
                q = arm.q()
                print(f"  q = [{', '.join(f'{v:.4f}' for v in q)}]   fk = "
                      f"({', '.join(f'{v:.4f}' for v in arm.fk())})")
            elif k in ("x", "y", "z", "phi"):
                d = float(cmd[1])
                if abs(d) > MAX_JOG and k != "phi":
                    print("  step too big")
                    continue
                x, y, z, phi = arm.fk()
                x, y, z, phi = (x + d * (k == "x"), y + d * (k == "y"), z + d * (k == "z"),
                                phi + d * (k == "phi"))
                if not arm.move_xyz(x, y, z, phi):
                    print("  unreachable")
            elif k in ("j1", "j2", "j3", "j4"):
                q = arm.q()
                q[int(k[1]) - 1] += float(cmd[1])
                arm.move(q)
            elif k == "touch":
                st.z_touch = arm.fk()[2]
                print(f"  z_touch = {st.z_touch:.4f}   -> {Heights(st.z_touch)}")
                st.save()
            elif k == "ref":
                st.q_ref = [float(v) for v in arm.q()]
                st.phi = arm.fk()[3]
                print(f"  q_ref saved, phi = {st.phi:.4f}")
                st.save()
            elif k == "observe":
                st.q_observe = [float(v) for v in arm.q()]
                st.save()
            else:
                print("  unknown command")
        except (ValueError, IndexError):
            print("  bad command")


# ======================================================================================
def calibrate(arm, st, sim=False, show=True, out="calib_result.png"):
    """
    Hoop on an N x N grid at two heights -> image (u, v) <-> flange (x, y) at each height
    -> two homographies. Uses the hoop orientation phi from `jog ref`, which must then be
    used for all hoop motions (the planner does).
    """
    st.require("z_touch", "q_ref", "phi")
    prompt("Remove the base plate with the rod from the turntable (keep the turntable). "
           "Press Enter when done.", sim)
    if sim and hasattr(arm.robot, "world"):
        arm.robot.world.board_present = False

    x0, y0, _, _ = arm.fk(st.q_ref)
    phi = st.phi
    z_low = st.z_touch + C.CALIB_Z_LOW_ABOVE_TOUCH
    z_high = st.z_touch + C.CALIB_Z_HIGH_ABOVE_TOUCH
    n, step = C.CALIB_GRID_N, C.CALIB_GRID_STEP
    offs = (np.arange(n) - (n - 1) / 2) * step
    grid = [(x0 + dx, y0 + dy) for dx in offs for dy in offs]

    arm.move_up_to(z_high)
    data = {}
    vis = None
    for name, z in (("high", z_high), ("low", z_low)):
        uv, xy, radii = [], [], []
        for (x, y) in grid:
            if not arm.move_xyz(x, y, z, phi):
                print(f"  [{name}] ({x:.3f}, {y:.3f}) unreachable - skipped")
                continue
            clock.sleep(C.SETTLE_TIME)
            img, _ = arm.grab()
            det = V.detect_hoop(img) if img is not None else None
            if det is None:
                print(f"  [{name}] ({x:.3f}, {y:.3f}) hoop NOT detected - skipped")
                continue
            fx, fy, _, _ = arm.fk()
            uv.append(det["center"])
            xy.append((fx, fy))
            radii.append(det["radius"])
            if vis is None:
                vis = img.copy()
            V.draw_hoop(vis, det, V.GREEN if name == "low" else V.BLUE)
        if len(uv) < 5:
            raise SystemExit(f"Only {len(uv)} hoop detections at the {name} plane - need 5+. "
                             f"Check HOOP_MIN_R/HOOP_MAX_R/HOOP_DARK in config.py with "
                             f"`--testing camera`, or reduce CALIB_GRID_STEP.")
        uv, xy = np.array(uv), np.array(xy)
        Hm, _ = cv2.findHomography(uv, xy, 0)
        err = np.linalg.norm(cv2.perspectiveTransform(uv.reshape(-1, 1, 2), Hm).reshape(-1, 2) - xy,
                             axis=1) * 1000
        print(f"  {name} plane z={z:.4f}: {len(uv)} points, error mean {err.mean():.2f} mm, "
              f"max {err.max():.2f} mm, hoop radius {np.mean(radii):.0f} px")
        data[name] = (Hm, z, float(np.mean(radii)))
    arm.move_up_to(z_high)

    if data["high"][2] <= data["low"][2]:
        raise SystemExit("The hoop looks SMALLER at the higher plane -> fk z probably grows "
                         "downwards on this robot. Flip the height logic before continuing.")
    st.H_high, st.z_high = data["high"][0].tolist(), data["high"][1]
    st.H_low, st.z_low = data["low"][0].tolist(), data["low"][1]
    st.image_size = [int(vis.shape[1]), int(vis.shape[0])]
    st.save()

    V.text_box(vis, [("CAMERA CALIBRATION", V.WHITE),
                     (f"blue: high plane  z={z_high:.3f}", V.BLUE),
                     (f"green: low plane  z={z_low:.3f}", V.GREEN)], (20, 20), border=V.WHITE)
    cv2.imwrite(out, vis)
    print(f"[overlay saved to {out}]")
    park(arm, st)
    prompt("Put the base plate with the rod back. Press Enter.", sim)
    if sim and hasattr(arm.robot, "world"):
        arm.robot.world.board_present = True
    if show:
        V.show(vis, "calibration")


# ======================================================================================
def drop_test(arm, st, sim=False, repeats=3):
    """Time the hover->final descent at the reference xy (nothing must be below the hoop)."""
    st.require("z_touch", "q_ref", "phi")
    prompt("Remove the base plate (the hoop will go down to plate height at the reference "
           "pose). Press Enter.", sim)
    if sim and hasattr(arm.robot, "world"):
        arm.robot.world.board_present = False
    H = st.heights()
    x, y, _, _ = arm.fk(st.q_ref)
    q_hi = arm.ik_near(x, y, H.safe, st.phi, st.q_ref)
    q_lo = arm.ik_near(x, y, H.final, st.phi, q_hi)
    if q_hi is None or q_lo is None:
        raise SystemExit("Reference pose not reachable at hover/final height")
    arm.move_up_to(H.safe)
    arm.move(q_hi)
    downs, ups, lat = [], [], []
    for _ in range(repeats):
        for target, store in ((q_lo, downs), (q_hi, ups)):
            q0 = arm.q()
            t0 = clock.now()
            arm.robot.move_to_q(list(target))
            while np.max(np.abs(arm.q() - q0)) < 1e-4 and clock.now() - t0 < 1.0:
                clock.sleep(0.005)
            lat.append(clock.now() - t0)
            arm.robot.wait_for_motion_stop()
            store.append(clock.now() - t0)
            clock.sleep(0.3)
    st.drop_time = float(np.mean(downs))
    st.lift_time = float(np.mean(ups))
    st.cmd_latency = float(min(np.median(lat), 0.3))
    print(f"  descent {st.drop_time:.3f} s (+-{np.std(downs) * 1000:.0f} ms), "
          f"lift {st.lift_time:.3f} s, command latency ~{st.cmd_latency * 1000:.0f} ms")
    st.save()
    park(arm, st)
    prompt("Put the base plate with the rod back. Press Enter.", sim)
    if sim and hasattr(arm.robot, "world"):
        arm.robot.world.board_present = True


# ======================================================================================
def camera_view(arm, st, q=None, show=True, out="camera_view.png"):
    if q is not None:
        if st.z_touch is not None:
            arm.move_up_to(st.heights().safe)
        arm.move(q)
    img, _ = arm.grab()
    if img is None:
        raise SystemExit("Could not grab an image")
    vis = img.copy()
    markers = V.detect_markers(img)
    V.draw_markers(vis, markers)
    lines = [("CAMERA VIEW", V.WHITE), (f"markers: {sorted(markers) or 'none'}", V.CYAN)]
    hoop = V.detect_hoop(img)
    if hoop is not None:
        V.draw_hoop(vis, hoop)
        lines.append((f"hoop at ({hoop['center'][0]:.0f}, {hoop['center'][1]:.0f}) px, "
                      f"r {hoop['radius']:.0f} px", V.GREEN))
    else:
        lines.append(("hoop not detected", V.GRAY))
    if st.missing("H_low", "H_high", "z_low", "z_high", "z_touch") == []:
        H, cam = st.heights(), st.camera()
        b = V.detect_board(img, cam, H.board)
        if b is not None:
            V.draw_cross(vis, cam.to_image(b["center"], H.board)[0], V.ORANGE)
            lines.append((f"plate centre ({b['center'][0]:.4f}, {b['center'][1]:.4f}) m, "
                          f"spacing err {b['spacing_err'] * 1000:+.1f} mm", V.ORANGE))
        else:
            lines.append(("plate: need both markers here", V.GRAY))
        rod = V.detect_rod_top(img, cam, H.rod_top)
        if rod is not None:
            V.draw_cross(vis, rod["uv"], V.YELLOW, 18, 3)
            lines.append((f"rod top (orange) at ({rod['xy'][0]:.4f}, {rod['xy'][1]:.4f}) m", V.YELLOW))
        else:
            lines.append(("rod top not found (ROD_HSV_* in config.py)", V.GRAY))
    V.text_box(vis, lines, (20, 20), border=V.WHITE)
    cv2.imwrite(out, vis)
    print("\n".join(t for t, _ in lines[1:]))
    print(f"[saved {out}]")
    if show:
        V.show(vis, "camera")


# ======================================================================================
def track_test(arm, st, validate_time=5.0, show=True, out="track_result.png"):
    """Fit the rotation, then keep watching and report how far the prediction is off."""
    from run_a2 import draw_plan
    st.require("z_touch", "H_low", "H_high", "z_low", "z_high")
    cam, H = st.camera(), st.heights()
    from run_a2 import safe_observe_q
    arm.move_up_to(H.safe)
    arm.move(safe_observe_q(arm, st, H))
    model, obs, img, board = observe(arm, cam, H.board)
    if model is None:
        raise SystemExit("Plate not tracked - check `--testing camera`")
    print(model.describe())

    errs, t_end = [], clock.now() + validate_time
    while clock.now() < t_end:
        im, t = arm.grab()
        b = V.detect_board(im, cam, H.board) if im is not None else None
        if b is not None:
            errs.append((t - model.t_ref, np.linalg.norm(model.rod(t) - b["center"])))
            img, board = im, b
    lines = []
    if errs:
        e = np.array([v for _, v in errs]) * 1000
        print(f"Prediction check over the next {validate_time:.0f} s: error mean {e.mean():.1f} mm, "
              f"max {e.max():.1f} mm (hoop allows ~23 mm)")
        lines.append((f"prediction error mean {e.mean():.1f} / max {e.max():.1f} mm", V.YELLOW))
    vis = draw_plan(img, cam, H, model, board, None, lines)
    cv2.imwrite(out, vis)
    print(f"[overlay saved to {out}]")
    if show:
        V.show(vis, "tracking")
    return model
